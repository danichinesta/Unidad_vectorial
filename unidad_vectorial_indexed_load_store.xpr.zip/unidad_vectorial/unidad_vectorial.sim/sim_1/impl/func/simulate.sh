#!/bin/bash -f
xv_path="/opt/Xilinx/Vivado/2016.2"
ExecStep()
{
"$@"
RETVAL=$?
if [ $RETVAL -ne 0 ]
then
exit $RETVAL
fi
}
ExecStep $xv_path/bin/xsim mux_param_tb_func_impl -key {Post-Implementation:sim_1:Functional:mux_param_tb} -tclbatch mux_param_tb.tcl -view /home/dchinue/workspace/unidad_vectorial.xpr/unidad_vectorial_con_alu_corr.xpr/unidad_vectorial/unidad_vectorial.srcs/sim_1/imports/unidad_vectorial/reg_y_mem_tb_behav.wcfg -log simulate.log
