#!/bin/bash -f
xv_path="/opt/Xilinx/Vivado/2016.2"
ExecStep()
{
"$@"
RETVAL=$?
if [ $RETVAL -ne 0 ]
then
exit $RETVAL
fi
}
ExecStep $xv_path/bin/xsim fifo_queue_tb_behav -key {Behavioral:sim_1:Functional:fifo_queue_tb} -tclbatch fifo_queue_tb.tcl -view /home/dchinue/workspace/unidad_vectorial.xpr/unidad_vectorial_regmux/unidad_vectorial_regmux_premultidelay.xpr/unidad_vectorial/unidad_vectorial.srcs/sim_1/imports/unidad_vectorial/reg_y_mem_tb_behav.wcfg -log simulate.log
