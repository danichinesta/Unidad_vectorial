#!/bin/bash -f
xv_path="/opt/Xilinx/Vivado/2016.2"
ExecStep()
{
"$@"
RETVAL=$?
if [ $RETVAL -ne 0 ]
then
exit $RETVAL
fi
}
ExecStep $xv_path/bin/xsim top_sqrt_rem_tb_behav -key {Behavioral:sim_1:Functional:top_sqrt_rem_tb} -tclbatch top_sqrt_rem_tb.tcl -view /home/dchinue/workspace/unidad_vectorial.xpr/unidad_vectorial_con_alu_corr.xpr/unidad_vectorial/unidad_vectorial.srcs/sim_1/imports/unidad_vectorial/reg_y_mem_tb_behav.wcfg -log simulate.log
